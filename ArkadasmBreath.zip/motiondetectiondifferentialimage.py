import cv2
import os
import time

def main():
    capWebcam = cv2.VideoCapture(0)
    fourcc = cv2.VideoWriter_fourcc(*'XVID')
    fullvideo = cv2.VideoWriter('fullvideodifferentialimage.avi', fourcc, 20.0, (640,480)) #writes full video
    movement=cv2.VideoWriter('movementdifferentialimage.avi', fourcc, 20.0, (640,480)) #writes only movements in the end
    if capWebcam.isOpened() == False:
        print ("error: capWebcam not accessed successfully\n\n")
        os.system("pause")
        return
    st = time.time() #starttime
    i=0
    while time.time()-st<=50 and capWebcam.isOpened(): #goes on for 1 minute and 3 secs, 1st 1 min-inactive last 3 sec-movements
        print(time.time() - st) #prints time passed
        blnFrameReadSuccessfully, imgOriginal = capWebcam.read()
        if not blnFrameReadSuccessfully or imgOriginal is None:
            print ("error: frame not read from webcam\n")
            os.system("pause")
            break
        imgGrayscale = cv2.cvtColor(imgOriginal, cv2.COLOR_BGR2GRAY) #converts to grayscale
        imgBlurred = cv2.GaussianBlur(imgGrayscale, (9, 9), 0) #blurs image to reduce noise
        cv2.imshow('frame1', imgBlurred) #shows gray blurred image
        if i!=0: #if its not the first frame
            difference=cv2.absdiff(imgBlurred,prev) #absolute difference, differential image, background subtraction
            diffblur= cv2.GaussianBlur(difference, (9, 9), 0) #blurs image to reduce noise
            thresholding = cv2.threshold(diffblur, 30, 255, cv2.THRESH_BINARY)[1] #thresholds image
            (_, contours, _)=cv2.findContours(thresholding, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE) #finds out contours
            for contour in contours: #iterates through contours
                if cv2.contourArea(contour) > 20: #if image size greater than some arbitrary value (value can be changed by should not be made too low)
                    movement.write(imgOriginal) #stores movements
                    if cv2.waitKey(1) & 0xFF == ord('q'):
                        break
            cv2.imshow('frame3', thresholding) #shows thresholded image
        i+=1
        prev = imgBlurred #stores prev frame
        fullvideo.write(imgOriginal) #writes full video
        if cv2.waitKey(1) & 0xFF == ord('q'):
            break
    capWebcam.release()
    fullvideo.release()
    cv2.destroyAllWindows()

if __name__ == "__main__": #main method
    main()